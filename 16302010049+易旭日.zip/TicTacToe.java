/**
 * Created by Administrator on 2016/11/1.
 */
import java.util.Scanner;
public class TicTacToe {//实现悔棋及取消悔棋。

    public static void main(String[] args) {
        char[][] board = {{'.', '.', '.'}, {'.', '.', '.'}, {'.', '.', '.'}};
        boolean player = true;
        char[][][] boardHistory = new char[100][][];
        int currentStep = 0;
        int lastStep = 0;
        int nextStep = 0;
        Scanner scanner = new Scanner(System.in);
        boardHistory[lastStep]  = TicTacToe.copyArray(board);//导入地图的初始状态。
        int n = 0;
        while (true) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print(board[i][j]);
                }
                System.out.println();
            }
            System.out.print("Next move: ");
            String order = scanner.next();
            switch (order.charAt(0)) {//判断输入的指令。
                case 'u':
                    nextStep = currentStep - order.length();
                    if (nextStep >= 0) {
                        board = TicTacToe.copyArray(boardHistory[nextStep]);
                        currentStep = nextStep;
                        if(order.length()%2!=0) {
                            player = !player;
                        }//实现悔棋并改变玩家。
                    }
                    else {
                        System.out.println("You have alreadly return to the beginning!");
                    }
                    break;
                case 'r':
                    nextStep = currentStep + order.length();
                    if (nextStep <= lastStep) {
                        board = TicTacToe.copyArray(boardHistory[nextStep]);
                        currentStep = nextStep;
                        if(order.length()%2!=0) {
                            player = !player;
                        }
                        //实现取消悔棋并改变玩家。
                    }
                    else
                        System.out.println("You ought to continue to play now!");
                    break;
                default:
                    int nextPosition = order.charAt(0) - '0';
                    board[nextPosition / 3][nextPosition % 3] = (player) ? 'O' : 'X';
                    if(lastStep== n ) {
                        lastStep++;
                        currentStep = lastStep;
                        boardHistory[lastStep] = TicTacToe.copyArray(board);
                        player = !player;
                    }
                    else{
                        lastStep =0;
                        n =0;
                        lastStep++;
                        currentStep = lastStep;
                        boardHistory[lastStep] = TicTacToe.copyArray(board);
                        player = !player;
                    }//用n与lastSteps是否相等判断是否经历悔棋以执行相应语句。
            }
            n  ++;
        }
    }

    private static char[][] copyArray(char[][] array) {//进行数组的复制并返回该数组。
        char[][] newArray = new char[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                newArray[i][j] = array[i][j];
            }
        }
        return newArray;
    }
}